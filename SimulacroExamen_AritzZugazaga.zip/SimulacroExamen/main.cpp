/*
 * main.cpp
 *
 *  Created on: 18 may. 2020
 *      Author: aritz
 */
#include <iostream>

using namespace std;

int main() {
	cout << "Hola Mundo" << endl;

	return 0;
}

